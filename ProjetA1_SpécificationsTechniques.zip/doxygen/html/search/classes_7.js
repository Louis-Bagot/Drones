var searchData=
[
  ['pyramidale',['Pyramidale',['../class_pyramidale.html',1,'']]]
];

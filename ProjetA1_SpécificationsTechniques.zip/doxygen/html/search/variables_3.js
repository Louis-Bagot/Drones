var searchData=
[
  ['origine',['origine',['../class_cubique.html#ab9d0ac86eeba76c72022bd84c401bb59',1,'Cubique']]]
];

var class_naif =
[
    [ "Naif", "class_naif.html#a4162a551c383243f3f5cc762ef0e63b8", null ],
    [ "~Naif", "class_naif.html#a30d91ce3f53ef01caae8b1d487f7e6e9", null ],
    [ "allerPoint", "class_naif.html#ac84cee4c23dea12b9e84789a41dc1d38", null ]
];